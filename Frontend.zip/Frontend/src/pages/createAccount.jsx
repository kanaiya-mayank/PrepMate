import React from 'react'

const createAccount = () => {
  return (
    <div>
      
    </div>
  )
}

export default createAccount
