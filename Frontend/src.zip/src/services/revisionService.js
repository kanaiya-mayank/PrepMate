/**
 * revisionService.js
 * Handles the logic for the Spaced Repetition System (SRS).
 * motive: Maximum retention for aspirants based on the forgetting curve.
 */

const REVISION_INTERVALS = [1, 3, 7, 21];

export const revisionService = {
  /**
   * Generates 4 revision dates based on a study session completion date.
   * @param {Date} completionDate - The date the student finished the sub-topic.
   * @returns {Array} An array of Date objects for the revision milestones.
   */
  calculateMilestones: (completionDate = new Date()) => {
    return REVISION_INTERVALS.map((days) => {
      const scheduledDate = new Date(completionDate);
      scheduledDate.setDate(completionDate.getDate() + days);
      // We set time to 00:00:00 to make daily comparisons easier for the backend
      scheduledDate.setHours(0, 0, 0, 0);
      return {
        interval: days,
        date: scheduledDate,
      };
    });
  },

  /**
   * Helper to categorize the urgency of a revision.
   */
  getUrgencyStatus: (scheduledDate) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const target = new Date(scheduledDate);
    target.setHours(0, 0, 0, 0);

    if (target < today) return 'overdue';
    if (target.getTime() === today.getTime()) return 'today';
    return 'upcoming';
  },

  /**
   * Formats the date to a readable string like "2 days ago" or "Yesterday"
   * Best for Aspirant UX so they don't have to calculate dates in their head.
   */
  formatRelativeDate: (date) => {
    const rtf = new Intl.RelativeTimeFormat('en', { numeric: 'auto' });
    const today = new Date().setHours(0, 0, 0, 0);
    const target = new Date(date).setHours(0, 0, 0, 0);
    const diffInDays = Math.round((target - today) / (1000 * 60 * 60 * 24));

    if (Math.abs(diffInDays) > 7) {
        return new Date(date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
    }
    return rtf.format(diffInDays, 'day');
  }
};